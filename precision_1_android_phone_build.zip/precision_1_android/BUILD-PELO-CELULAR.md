# Gerar o APK pelo celular

1. No navegador, entre em https://github.com e crie uma conta ou entre na sua.
2. Crie um repositório novo chamado `precision-1-android`.
3. Envie todos os arquivos e pastas deste ZIP para o repositório. Ative a opção de mostrar arquivos ocultos para incluir `.github/workflows/android.yml`.
4. Abra a aba Actions do repositório.
5. Se aparecer a confirmação de workflows, habilite-os.
6. Escolha `Build Precision 1.0 APK` e toque em `Run workflow`.
7. Aguarde a execução terminar com sucesso.
8. Abra a execução concluída e baixe o artefato `Precision-1.0-APK`.
9. Extraia o ZIP baixado e toque em `app-release.apk` para instalar.

O APK é gerado na nuvem. O app oferece perfis de sensibilidade e checklist de otimização; não injeta código no Free Fire.
