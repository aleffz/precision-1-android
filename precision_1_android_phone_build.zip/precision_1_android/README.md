# Precision 1.0 — Android

Projeto Flutter de painel gamer com tema preto/vermelho neon.

## O que inclui
- Ajustes de sensibilidade editáveis.
- Perfis Equilibrado, Precisão e Rápido.
- Salvamento local com SharedPreferences.
- Copiar configurações para aplicar manualmente no jogo.
- Checklist de otimização segura do aparelho.

O app não injeta código no Free Fire, não altera sua memória e não automatiza mira.

## Como gerar o APK
1. Instale Flutter SDK e Android Studio em um computador.
2. Extraia este projeto.
3. Abra um terminal na pasta `precision_1`.
4. Execute:
   flutter create .
   flutter pub get
   flutter build apk --release
5. O APK será gerado em:
   build/app/outputs/flutter-apk/app-release.apk

Para instalar no Android, transfira o APK para o aparelho e abra o arquivo.
